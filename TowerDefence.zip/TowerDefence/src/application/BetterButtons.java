package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class BetterButtons {
	public static Button createButton(String buttonText, Font font, ImageView imageView) {
        Button button = new Button();
        
        
        Text outlineText = new Text(buttonText);
        outlineText.setFont(font);
        outlineText.setStroke(Color.web("#444444"));
        outlineText.setStrokeWidth(3); // Outline Text Settings

        Text mainText = new Text(buttonText);
        mainText.setFont(font);
        mainText.setFill(Color.web("#EEEEEE")); //Main Text Settings

        StackPane textLayer = new StackPane(outlineText, mainText);
        HBox buttonLayer = new HBox(imageView, textLayer);
        buttonLayer.setSpacing(10);
        button.setGraphic(buttonLayer);
        button.setPadding(new Insets(25, 30, 25, 30));
        button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
        

    	button.setOnMouseEntered(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#8A8A8A"), new CornerRadii(16), new Insets(-3))));
    		buttonLayer.setOpacity(0.8);
    		button.setGraphic(buttonLayer);
    		}
    	);
    		
    	button.setOnMouseExited(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(1);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMousePressed(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#5A5A5A"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(0.7);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMouseDragged(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#505050"), new CornerRadii(24), new Insets(1))));
    		buttonLayer.setOpacity(0.6);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMouseReleased(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(1);
    		button.setGraphic(buttonLayer);
    		}
    	);
        
        return button;
    }
	
	public static Button createTowerButton(String buttonText, Font font, Tower tower, ImageView imageView) {
        Button button = new Button();
        
        Text outlineText = new Text(buttonText);
        outlineText.setFont(font);
        outlineText.setStroke(Color.web("#444444"));
        outlineText.setStrokeWidth(3); // Outline Text Settings

        Text mainText = new Text(buttonText);
        mainText.setFont(font);
        mainText.setFill(Color.web("#EEEEEE")); //Main Text Settings

        StackPane textLayer = new StackPane(outlineText, mainText);
        HBox buttonLayer = new HBox(imageView, textLayer);
        buttonLayer.setSpacing(10);
        button.setGraphic(buttonLayer);
        button.setPadding(new Insets(5, 10, 5, 10));
        button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
        

    	button.setOnMouseEntered(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#8A8A8A"), new CornerRadii(16), new Insets(-3))));
    		buttonLayer.setOpacity(0.8);
    		button.setGraphic(buttonLayer);
    		}
    	);
    		
    	button.setOnMouseExited(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(1);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMousePressed(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#5A5A5A"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(0.7);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMouseDragged(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#505050"), new CornerRadii(24), new Insets(1))));
    		buttonLayer.setOpacity(0.6);
    		button.setGraphic(buttonLayer);
    		}
    	);

    	button.setOnMouseReleased(e -> {
    		button.setBackground(new Background(new BackgroundFill(Color.web("#787878"), new CornerRadii(20), new Insets(0))));
    		buttonLayer.setOpacity(1);
    		button.setGraphic(buttonLayer);
    		}
    	);
    	
    	Tower towers = createNewTowerInstance(tower);
    	button.setUserData(towers);
        return button;
    }
	
	private static Tower createNewTowerInstance(Tower original) {
	    if (original instanceof WatchTower) {
	        return new WatchTower();
	    } else if (original instanceof TripleTower) {
	        return new TripleTower();
	    } else if (original instanceof InfernoTower) {
	        return new InfernoTower();
	    } else if (original instanceof BombTower) {
	        return new BombTower();
	    }
	    throw new IllegalArgumentException("Unknown tower type");
	}

}
