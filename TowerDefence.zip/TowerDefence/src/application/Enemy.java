package application;

import javafx.util.Duration;
import java.util.ArrayList;
import javafx.animation.Interpolator;
import javafx.animation.PathTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;

abstract class Enemy extends StackPane {
	
	private int hp;
	private int speed;
	private int physicalArmor;
	private int magicArmor;
	private int damage;
	private int killReward;
	private PathTransition movementTransition;
	static ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
	private Rectangle hBar;
	private Path path;
	private ImageView enemyImageView; //to show the enemy Image
	private static int squareSize;
	
	
	Enemy(int hp, int speed, int physicalArmor, int magicArmor, int damage, int killReward, String imagePath) {
		
		this.hp = hp;
		this.speed = speed;
		this.physicalArmor = physicalArmor;
		this.magicArmor = magicArmor;
		this.damage = damage;
		this.killReward = killReward;
		this.hBar = EnemyEffect.createHBar(this);
		this.loadImage(imagePath);
	}
	
	
	public static void setSquareSize(int squareSize) {
        Enemy.squareSize = squareSize;
    }
	
	public void loadImage(String imagePath) { 	// Loads the image of Enemy.
		
		 try {
		        enemyImageView = new ImageView(new Image(getClass().getResource(imagePath).toString()));
		        if (this instanceof Rogue) {
		            enemyImageView.setFitWidth(squareSize / 4.0);
		            enemyImageView.setFitHeight(squareSize / 4.0);
		        }
		        else if (this instanceof Goblin) {
		            enemyImageView.setFitWidth(squareSize / 5.0);
		            enemyImageView.setFitHeight(squareSize / 5.0);
		        }
		        else if (this instanceof Tank) {
		            enemyImageView.setFitWidth(squareSize / 2.0);
		            enemyImageView.setFitHeight(squareSize / 2.0);
		        }
		        else if (this instanceof Warrior) {
		            enemyImageView.setFitWidth(squareSize / 3.0);
		            enemyImageView.setFitHeight(squareSize / 3.0);
		        }
		        enemyImageView.setPreserveRatio(true);
		        this.getChildren().add(enemyImageView);
		        
		    } catch (Exception e) {
		        System.err.println("Image could not find: " + imagePath);
		        enemyImageView = new ImageView();
		    }
	}
	
	public static void callHpUpdate() {	// In case of us needing a static method for global update.
		
		for (Enemy enemy : Enemy.enemyList) {
			enemy.updateHealthBar();
		}
	}
	
	public void updateHealthBar() {
		
		int baseHp = 0;
		
		if (this instanceof Rogue)		// Find the class of given instance.
			baseHp = 250;
		
		else if (this instanceof Warrior)
			baseHp = 300;
		
		else if (this instanceof Goblin)
			baseHp = 120;
		
		else 
			baseHp = 500;
		
		if (this.getHBar() != null && this.getHBar().getWidth() > 0) {	// Chech if enemy is legit. Then update the Bar.
            this.getHBar().setWidth((40 * getHp() / baseHp));
        }
		
		else {
			this.getHBar().setVisible(false);
		}
	}
	
	public void startMovement() {	// Creates a transition for enemies to move on with a constant speed on given path.
	    
		movementTransition = new PathTransition();
		movementTransition.setNode(this);
		movementTransition.setPath(Game.getActiveGameMaps().getPath());
		movementTransition.setDuration(Duration.seconds(1 * Game.getActiveGameMaps().getPathLength() / speed));
		movementTransition.setInterpolator(Interpolator.LINEAR);
		movementTransition.setCycleCount(1);
		movementTransition.setOnFinished(e -> {
	    	
	        if (hp > 0) {		// If enemy finished the path without dying, then player will take damage and enemy's job will be done.
	        	
	            stopMovement();
				try {
					this.doDmg();
					
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
	            this.setVisible(false);
	            this.getHBar().setVisible(false);
	            enemyList.remove(this);
	            Game.getActiveGameMaps().getPathDemo().getChildren().remove(this.getHBar());
	            Game.getActiveGameMaps().getPathDemo().getChildren().remove(this);
				
				for (Tower tower : Tower.towerList) {
					
					if (tower instanceof InfernoTower && tower != null) {
						
						Laser.updateLines(((InfernoTower) tower).lines, (InfernoTower) tower);
					}
				}
				
	        }
	    });
		
		movementTransition.play();
	}
	
	public void stopMovement() {		// We use this when enemy dies.
		
		if (this.movementTransition != null) {
			
	        this.movementTransition.pause();
	        this.movementTransition = null;
	    }
    }
	
	public void getHurt(int dmg, int type) {	// Makes the enemy take damage according to towers damage and damage type. Calls die() method if enemy dies after taking damage.
		
		if (type == 0) 
			this.setHp(this.getHp() - (int)(dmg * (100 - this.getPhysicalArmor()) / 100.0 ));
		
		else if (type == 1)
			this.setHp(this.getHp() - (int)(dmg * (100 - this.getMagicArmor()) / 100.0 ));
		
		else
			this.setHp(getHp() - dmg);
		
		this.updateHealthBar();		// Update the length of health bar according to the new HP.
		
		if (this.getHp() == 0) {
			
			this.updateHealthBar();	// Double check to be sure for no reason at all.
			this.die();
		}
	}
	
	void die() {		// Gives the player its kill reward, then "removes" everything about that enemy.
		
	    Player.changeMoney(this.getKillReward());
	    this.getHBar().setVisible(false);
	    EnemyEffect.createParticles(this, Game.getActiveGameMaps().getPathDemo(), 10);
	    this.stopMovement();
	    this.setVisible(false);
	    enemyList.remove(this);
	}
	
	public void doDmg() throws InterruptedException {		// Enemy do damage, enemy scary!
		
		Player.changeLives((Enemy) this);
	}
	
	public double getX() {				// Getting the X,Y values of the middle point.
		
		return this.getLayoutX() + this.getWidth() / 2;
	}
	
	public double getY() {
		
		return this.getLayoutY() + this.getHeight() / 2;
	}
	
	
	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		
		if (hp < 0)			// If HP becomes negative, then makes it equal to 0.
			this.hp = 0;
		
		else
			this.hp = hp;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getPhysicalArmor() {
		return physicalArmor;
	}

	public void setPhysicalArmor(int physicalArmor) {
		this.physicalArmor = physicalArmor;
	}

	public int getMagicArmor() {
		return magicArmor;
	}

	public void setMagicArmor(int magicArmor) {
		this.magicArmor = magicArmor;
	}
	
	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	public int getKillReward() {
		return killReward;
	}

	public void setKillReward(int killReward) {
		this.killReward = killReward;
	}
	
	public Rectangle getHBar() {
		return hBar;
	}
	
	public void setHBar(Rectangle hBar) {
		this.hBar = hBar;
	}

	public Path getPath() {
		return path;
	}

	public void setPath(Path path) {
		this.path = path;
	}

}

// Our 4 types of enemies:
class Rogue extends Enemy {
	
	Rogue() {
		
		super(250, 2, 0,0 , 1 , 20, "/images/rogue.png");
	}
	
}

class Warrior extends Enemy {
	
	Warrior() {
		
		super(300, 2, 25,0 , 2 , 30, "/images/warrior.png");
	}
	
}

class Goblin extends Enemy {
	
	Goblin() {
		
		super(120, 3, 0,25 , 1 , 20, "/images/goblin.png");
	}
	
}

class Tank extends Enemy {
	
	Tank() {
		
		super(500, 1, 75,0 , 3 , 100, "/images/tank.png");
	}

}