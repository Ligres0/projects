package application;	// MİRZA

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
import javafx.scene.shape.Rectangle;

public class EnemyEffect {
	
    static int radius = 4;
    static double lifespan = 0.5; 	// Lifespan in seconds
    static double maxRange = 20;	// Max range of death particles from the enemy's location.
    Circle particle;
    
    
    public EnemyEffect(Enemy enemy, Pane parentPane) {
        particle = new Circle(radius);
        
        particle.setCenterX(enemy.getTranslateX() + enemy.getWidth() / 2);
        particle.setCenterY( enemy.getTranslateY() + enemy.getHeight() / 2);
        particle.setFill(Color.web("#991111"));
        
        parentPane.getChildren().add(particle);
        startEffect(parentPane);
    }

    
    private void startEffect(Pane parentPane) {
        
        TranslateTransition move = new TranslateTransition(Duration.seconds(lifespan), particle);	// Random movement
        move.setByX((2 * Math.random() - 1) * maxRange);
        move.setByY((2 * Math.random() - 1) * maxRange);

        FadeTransition fade = new FadeTransition(Duration.seconds(lifespan), particle);	// Fade out
        fade.setFromValue(1.0);
        fade.setToValue(0.0);

        move.play();
        fade.play();
        fade.setOnFinished(e -> 
        	Platform.runLater(() -> parentPane.getChildren().remove(particle))	// To ensure that code works properly.
        	);
    }

    public static void createParticles(Enemy enemy, Pane parentPane, int count) {	// Particle creator of given amount.
    	
        for (int i = 0; i < count; i++) {
            new EnemyEffect(enemy, parentPane);
        }
    }
    
    public static Rectangle createHBar(Enemy enemy) {	// Constructor for HP bar.
    	
    	Rectangle hpBar = new Rectangle(enemy.getX(), enemy.getY() , 40, 8);	// 40 Width and 8 Height
    	hpBar.setFill(Color.ORANGERED);
    	hpBar.setStroke(Color.DARKRED);
    	hpBar.translateXProperty().bind(enemy.translateXProperty().add(hpBar.getWidth() / 2));
    	hpBar.translateYProperty().bind(enemy.translateYProperty().subtract(TowerReplace.getSquareSize() / 4));
    	
    	return hpBar;
    }
}