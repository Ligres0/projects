package application;
import java.io.FileNotFoundException;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Game extends Application {
	
	public static Stage primaryStage;
	public static Scene menuScene;
	public static GameMaps activeGameMaps;
	
    @Override
    public void start(Stage primaryStage) {
    	
    	Game.primaryStage = primaryStage;
    	
        StackPane root = new StackPane();
        VBox pane = new VBox();
        
        root.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/white_bg.png").toString())
    					)
    			);
        
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(150);
        
        Font buttonFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 36);
        Button button = BetterButtons.createButton("Play", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
        
        StackPane spGameName = new StackPane();
        Font mainFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 100);
        Text gameNameOutline = new Text("TOWER DEFENSE GAME");
        gameNameOutline.setFont(mainFont);
        gameNameOutline.setStroke(Color.web("#D4AF37"));
        gameNameOutline.setStrokeWidth(6); // Outline Text Settings

        Text gameNameMain = new Text("TOWER DEFENSE GAME");
        gameNameMain.setFont(mainFont);
        gameNameMain.setFill(Color.web("#FFD700")); //Main Text Settings
        
        spGameName.getChildren().add(gameNameOutline);
        spGameName.getChildren().add(gameNameMain);

        pane.getChildren().addAll(spGameName, button);
        root.getChildren().add(pane);
        menuScene = new Scene(root, 1440, 810);

        button.setOnAction(e -> {
        	try {
                GameMaps gameMaps = new GameMaps(1);
                setActiveGameMaps(gameMaps);
                Scene gameScene;
				try {
					gameScene = gameMaps.GameScene();
					primaryStage.setScene(gameScene);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
                
                primaryStage.setFullScreen(true);
                primaryStage.setFullScreenExitHint("");
                
                Timeline timeline = gameMaps.getMainAnimation();
                Platform.runLater(() -> timeline.play());
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        });
      

        primaryStage.setTitle("TOWER DEFENSE GAME");
        primaryStage.setScene(menuScene);
        primaryStage.setFullScreen(true);
        primaryStage.setFullScreenExitHint("");
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
        }
    
	public static GameMaps getActiveGameMaps() {
		return activeGameMaps;
	}
	
	public static void setActiveGameMaps(GameMaps gameMaps) {
		activeGameMaps = gameMaps;
	}
	
}