package application;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.layout.CornerRadii;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class GameMaps{
	private StackPane root;//Root pane which has everything in it
	private GridPane plane; // plane pane which has squares in it
	private GridPane ui; //UI pane which has plane and towers panes in it
	private StackPane[][] stackPanes;
	private Rectangle[][] rectangles;
	private Timeline mainAnimation;
	private Path path;
	private Pane pathDemo;//TODO:BU SADECE DEMO SATIRI
	TowerReplace towerReplace;//eklenen
	private int pathLength;
	private VBox leftPanel;
	private VBox towers; //towers pane which has towers, money etc. in it
	private Timeline sceneChange; //to stop the waveSpawn timeLine if the Player lost
	private StackPane trashBin = new StackPane();//to sell towers
	
	
	public GameMaps(int level) {
		
		root = new StackPane();//Root pane which has everything in it
		plane = new GridPane(); // plane pane which has squares in it
		ui = new GridPane(); //UI pane which has plane and towers panes in it
		mainAnimation = new Timeline();
		path = new Path();
		pathDemo = new Pane();//this is the main pane which everything which has action in it
		towerReplace = new TowerReplace();
		leftPanel = new VBox();
		towers = new VBox(); //towers pane which has towers, money etc. in it
		
		trashBin = new StackPane();
		
		root.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/white_bg.png").toString())
    					)
    			);
    	root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.getChildren().add(ui);
        
        ui.setAlignment(Pos.CENTER);
        ui.setHgap(18);
        ui.setPadding(new Insets(10, 10, 10, 10));
        
        pathDemo.getChildren().add(plane);
        pathDemo.getChildren().add(this.path);
        ui.add(leftPanel, 0, 0);
        ui.add(pathDemo, 1, 0);
        ui.add(towers, 2, 0);
        
    	plane.setPadding(new Insets(6));//6 pixels gap from edges
        plane.setHgap(2);//2 pixels gap between horizontal children
        plane.setVgap(2);//2 pixels gap between vertical children
        plane.setBackground(new Background(new BackgroundFill(Color.web("#0D460D"), new CornerRadii(12), new Insets(0))));
        
        leftPanel.setMinSize(320, 640);
        leftPanel.setAlignment(Pos.CENTER);
        leftPanel.setPadding(new Insets(12));
        leftPanel.setSpacing(12);
        leftPanel.setBackground(new Background(new BackgroundFill(Color.web("#4A4A4A"), new CornerRadii(16), new Insets(0))));
        
        trashBin.setMinSize(145, 145);
        trashBin.setMaxSize(145, 145);
        trashBin.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/trashBin.png").toString())
    					)
    			);
        trashBin.setBackground(new Background(new BackgroundFill(Color.web("#A8A8A8"), new CornerRadii(12), new Insets(0))));
        leftPanel.getChildren().add(trashBin);
        
        
        towers.setMinSize(320, 640);
        towers.setPadding(new Insets(12));
        towers.setSpacing(12);
        towers.setBackground(new Background(new BackgroundFill(Color.web("#4A4A4A"), new CornerRadii(16), new Insets(0))));
        
        path.setStroke(Color.TRANSPARENT); // Path Color (It was only for testing, we made it transparent right after we finished working on the project)
        path.setStrokeWidth(3); // PathWidth (It was only for testing)
        
        
        Tower watchTowerPrototype = new WatchTower();
        Tower tripleTowerPrototype = new TripleTower();
        Tower infernoTowerPrototype = new InfernoTower();
        Tower bombTowerPrototype = new BombTower();
        
        Font buttonFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 24);
        
        StackPane spHealth = new StackPane();
        Label health = createLabel(spHealth, "" + Player.getLives(), Player.livesProperty(), new ImageView(new Image(getClass().getResource("/images/health.png").toString())));
        spHealth.getChildren().add(health);
        towers.getChildren().add(spHealth);
        
        StackPane spCoin = new StackPane();
        Label coin = createLabel(spCoin, "" + Player.getMoney(), Player.moneyProperty(), new ImageView(new Image(getClass().getResource("/images/coin.png").toString())));
        spCoin.getChildren().add(coin);
        towers.getChildren().add(spCoin);
        
        
        StackPane spButton1 = new StackPane();	
        Button button1 = BetterButtons.createTowerButton("     Cannon      ", buttonFont, watchTowerPrototype, new ImageView(new Image(getClass().getResource(watchTowerPrototype.getImagePath()).toString())));
        spButton1.getChildren().add(button1);
        towers.getChildren().add(spButton1);
        
        
        StackPane spButton2 = new StackPane();
        Button button2 = BetterButtons.createTowerButton("Triple Cannon", buttonFont, tripleTowerPrototype, new ImageView(new Image(getClass().getResource(tripleTowerPrototype.getImagePath()).toString())));
        spButton2.getChildren().add(button2);
        towers.getChildren().add(spButton2);
        
        StackPane spButton3 = new StackPane();
        Button button3 = BetterButtons.createTowerButton("Electro Tower", buttonFont, infernoTowerPrototype, new ImageView(new Image(getClass().getResource(infernoTowerPrototype.getImagePath()).toString())));
        spButton3.getChildren().add(button3);
        towers.getChildren().add(spButton3);
        
        StackPane spButton4 = new StackPane();
        Button button4 = BetterButtons.createTowerButton("     Mortar      ", buttonFont, bombTowerPrototype, new ImageView(new Image(getClass().getResource(bombTowerPrototype.getImagePath()).toString())));
        spButton4.getChildren().add(button4);
        towers.getChildren().add(spButton4);
        
        StackPane spWaveButton = new StackPane();
        Button waveButton = BetterButtons.createButton("   Start Waves   ", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
        spWaveButton.getChildren().add(waveButton);
        towers.getChildren().add(spWaveButton);
        
        waveButton.setOnAction(e -> {
            try {
                waveButton.setDisable(true);
                double initialTime = 3;
                double spawnIntervalSeconds = 0.5;
                WaveSpawn.spawnWave(level, 1, initialTime, spawnIntervalSeconds, plane, path);

                int[] remainingTime1 = {(int) (initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds)};

                Timeline countdown1 = new Timeline(new KeyFrame(Duration.seconds(1), e2 -> {
                    if (remainingTime1[0] > 0) {
                        Text outlineText = new Text("Wave 2 in " + remainingTime1[0] + " seconds...");
                        outlineText.setFont(buttonFont);
                        outlineText.setStroke(Color.web("#444444"));
                        outlineText.setStrokeWidth(3);

                        Text mainText = new Text("Wave 2 in " + remainingTime1[0] + " seconds...");
                        mainText.setFont(buttonFont);
                        mainText.setFill(Color.web("#EEEEEE"));

                        StackPane textLayer = new StackPane(outlineText, mainText);
                        HBox buttonLayer = new HBox(textLayer);
                        buttonLayer.setSpacing(10);
                        waveButton.setGraphic(buttonLayer);

                        remainingTime1[0]--;
                    } else {
                        ((Timeline)e2.getSource()).stop();
                    }
                }));

                countdown1.play();
                
                Timeline wave2 = new Timeline(new KeyFrame(Duration.seconds(initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds), w2 -> {
                    if (Player.getLives() > 0) {
                    	WaveSpawn.spawnWave(level, 2, initialTime, spawnIntervalSeconds, plane, path);
                    }
                }));
                wave2.play();
                
                int[] remainingTime2 = {(int) (initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds)};

                Timeline countdown2 = new Timeline(new KeyFrame(Duration.seconds(1), t2 -> {
                    if (remainingTime2[0] > 0) {
                        Text outlineText = new Text("Wave 3'll come in " + remainingTime2[0] + " seconds...");
                        outlineText.setFont(buttonFont);
                        outlineText.setStroke(Color.web("#444444"));
                        outlineText.setStrokeWidth(3);

                        Text mainText = new Text("Wave 3'll come in " + remainingTime2[0] + " seconds...");
                        mainText.setFont(buttonFont);
                        mainText.setFill(Color.web("#EEEEEE"));

                        StackPane textLayer = new StackPane(outlineText, mainText);
                        HBox buttonLayer = new HBox(textLayer);
                        buttonLayer.setSpacing(10);
                        waveButton.setGraphic(buttonLayer);

                        remainingTime2[0]--;
                    } else {
                        ((Timeline)t2.getSource()).stop();
                    }
                }));
                
                countdown2.play();
                
                Timeline wave3 = new Timeline(new KeyFrame(Duration.seconds(initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds), w3 -> {
                	if (Player.getLives() > 0) {
                    	WaveSpawn.spawnWave(level, 3, initialTime, spawnIntervalSeconds, plane, path);
                    }
                }));
                wave3.play();
                
                int[] remainingTime3 = {(int) (initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds)};

                Timeline countdown3 = new Timeline(new KeyFrame(Duration.seconds(1), t3 -> {
                    if (remainingTime3[0] > 0) {
                        Text outlineText = new Text("Level " + level);
                        outlineText.setFont(buttonFont);
                        outlineText.setStroke(Color.web("#444444"));
                        outlineText.setStrokeWidth(3);

                        Text mainText = new Text("Level " + level);
                        mainText.setFont(buttonFont);
                        mainText.setFill(Color.web("#EEEEEE"));

                        StackPane textLayer = new StackPane(outlineText, mainText);
                        HBox buttonLayer = new HBox(textLayer);
                        buttonLayer.setSpacing(10);
                        waveButton.setGraphic(buttonLayer);

                        remainingTime3[0]--;
                    } else {
                        ((Timeline)t3.getSource()).stop();
                    }
                }));
                
                countdown3.play();
                
                // Calculate total duration for all waves
                double totalWaveDuration = (initialTime + WaveSpawn.spawnQueue.size() * spawnIntervalSeconds) * 3; // For 3 waves
                sceneChange = new Timeline(new KeyFrame(Duration.seconds(totalWaveDuration), t3 -> {
                	if(Player.getLives() > 0) {
                		GapScenes won = new GapScenes();
                        Game.primaryStage.setScene(won.winScene(Game.primaryStage, level));
                        Game.primaryStage.setFullScreen(true);
                        Game.primaryStage.setFullScreenExitHint("");
                	}
                }));
                
                sceneChange.play();
                
            } catch (Exception ex) {
                System.err.println("Wave spawn failed:");
                ex.printStackTrace();
            }
        });
        
        towerReplace.enableDrag(button1);
        towerReplace.enableDrag(button2);
        towerReplace.enableDrag(button3);
        towerReplace.enableDrag(button4);
        
        switch (level) {
        	case 1:
        		TowerReplace.setSquareSize(90);
        		Enemy.setSquareSize(90);
        		planeCreator(1, 8,mainAnimation, plane);
        		break;
        	case 2:
        		TowerReplace.setSquareSize(80);
        		Enemy.setSquareSize(80);
        		planeCreator(2, 9,mainAnimation, plane);
        		break;
        	case 3:
        		TowerReplace.setSquareSize(72);
        		Enemy.setSquareSize(72);
        		planeCreator(3, 10,mainAnimation, plane);
        		break;
        	case 4:
        		TowerReplace.setSquareSize(60);
        		Enemy.setSquareSize(60);
        		planeCreator(4, 12,mainAnimation, plane);
        		break;
        	case 5:
        		TowerReplace.setSquareSize(48);
        		Enemy.setSquareSize(48);
        		planeCreator(5, 15,mainAnimation, plane);
        		break;
        		
        }
        towerReplace.enableDrop(stackPanes);
        towerReplace.enableTrashBinDrop(trashBin);
	}
	
	public Timeline getSceneChange() {
		return sceneChange;
	}
	
    public Scene GameScene() throws InterruptedException, FileNotFoundException {
    	
        Scene scene = new Scene(root, 1440, 810);
        
        return scene;
    }
    
    public void clearRoot() {
    	if (root != null) {
    	    root.getChildren().clear();
    	}
    }
    
    public Pane getPathDemo() {
    	return this.pathDemo;
    }
    public GridPane getPlane() {
    	return this.plane;
    }
    
    public int getPathLength() {
    	return this.pathLength;
    }
    
    public Path getPath() {
    	return this.path;
    }
    
    public void pathSetter(ArrayList<int[]> coordinates) {
    	this.path.getElements().clear();
    	for (int i = 0; i < coordinates.size(); i++) {
    		if (i == 0) {
    			this.path.getElements().addAll(new MoveTo(coordinates.get(i)[0],coordinates.get(i)[1]));
    		}
    		else {
    			this.path.getElements().addAll(new LineTo(coordinates.get(i)[0],coordinates.get(i)[1]));
    		}
    	}
    }
    
    public Timeline getMainAnimation() {
    	return mainAnimation;
    }
    public void startAnimation(Timeline mainAnimation) {
    	mainAnimation.play();
    }
    
    public Label createLabel(StackPane spLabel, String labelText, IntegerProperty property, ImageView imageView) {
    	Label label = new Label();
        spLabel.setBackground(new Background(new BackgroundFill(Color.web("#A8A8A8"), new CornerRadii(20), new Insets(0))));
        spLabel.setMinSize(0, 0);
        
        Text outlineText = new Text(labelText);
        outlineText.textProperty().bind(property.asString());
        outlineText.setFont(Font.font("Arial", 50));
        outlineText.setStroke(Color.web("#444444"));
        outlineText.setStrokeWidth(5); // Outline Text Settings

        Text mainText = new Text(labelText);
        mainText.textProperty().bind(property.asString());
        mainText.setFont(Font.font("Arial", 50));
        mainText.setFill(Color.web("#EEEEEE")); //Main Text Settings
        
        StackPane textLayer = new StackPane(outlineText, mainText);
        HBox labelLayer = new HBox(textLayer, imageView);
        labelLayer.setSpacing(10);
        label.setGraphic(labelLayer);
        label.setPadding(new Insets(10, 20, 10, 20));
        label.setBackground(new Background(new BackgroundFill(Color.web("#A8A8A8"), new CornerRadii(20), new Insets(0))));
        
    	return label;
    }
    
    
    
    void planeCreator(int level, int squareNumber, Timeline sequentialAnimation, GridPane plane) {
    	int squareSize = 720/squareNumber;
    	
    	plane.setPrefSize(720 + 12 + (squareNumber - 1) * 2, 720 + 12 + (squareNumber - 1) * 2);
    	this.pathDemo.setMinSize(720 + 12 + (squareNumber - 1) * 2, 720 + 12 + (squareNumber - 1) * 2);
    	this.pathDemo.setPrefSize(720 + 12 + (squareNumber - 1) * 2, 720 + 12 + (squareNumber - 1) * 2);
    	this.pathDemo.setMaxSize(720 + 12 + (squareNumber - 1) * 2, 720 + 12 + (squareNumber - 1) * 2);
    	this.rectangles = new Rectangle[squareNumber][squareNumber];
        this.stackPanes = new StackPane[squareNumber][squareNumber];
        
        for (int i = 0; i < squareNumber; i++) {
        	for (int j = 0; j < squareNumber; j++) {
        		rectangles[i][j] = new Rectangle(squareSize, squareSize);
        		rectangles[i][j].setVisible(false);
        		rectangles[i][j].setFill(Color.web(randomGreen()));
        		stackPanes[i][j] = new StackPane();
        		stackPanes[i][j].setMinSize(squareSize, squareSize);
        		stackPanes[i][j].setUserData(new int[]{i, j});//to be able to put the tower in the right spot after this
        		plane.add(stackPanes[i][j], i, j);
        		
        		stackPanes[i][j].getChildren().add(rectangles[i][j]);
        	}
        }
        pathSetter(pathLoader(rectangles, level, squareNumber));
        
        

        for (int i = 0; i < squareNumber; i++) {
            for (int j = 0; j < squareNumber; j++) {
                final int row = i;
                final int col = j;
                
                sequentialAnimation.getKeyFrames().add(
                    new KeyFrame(Duration.millis((i + j) * 120),
                    event -> {
                    	rectangles[row][col].setWidth(0);
                    	rectangles[row][col].setHeight(0);
                    	rectangles[row][col].setVisible(true);
                        animateSquare(this.rectangles[row][col], squareSize);
                    }
                ));
                    
            }
        }
        
    }
    
    String randomPathColor() {
    	String[] paths = new String[3];
    	paths[0] = "C2A580";
    	paths[1] = "#B99A6E";
    	paths[2] = "#AD8B65";
    	return paths[(int)(Math.random() * 3)];
    }
    
    String randomGreen() {
    	String[] greens = new String[5];
		greens[0] = "#117A11";
		greens[1] = "#0B6A0B";
		greens[2] = "#1A8A1A";
		greens[3] = "#2C9C2C";
		greens[4] = "#106E10";
		return greens[(int)(Math.random() * 5)];
		
    }
    
    void animateSquare(Rectangle rectangle, int squareSize) {
        Timeline timeline = new Timeline();
        int time = 300;
        for (int k = 0; k <= time; k++) {
            
            timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(k),
                    new KeyValue(rectangle.widthProperty(), k * squareSize / time),
                    new KeyValue(rectangle.heightProperty(), k * squareSize / time),
                    new KeyValue(rectangle.arcWidthProperty(), k * squareSize / (time * 4)),
                    new KeyValue(rectangle.arcHeightProperty(), k * squareSize / (time * 4))
                )
            );
        }
        timeline.setCycleCount(1);
        timeline.play();
    }

    ArrayList<int[]> pathLoader(Rectangle[][] rectangles,int level, int squareNumber) {
		switch (level) {
			case 1:
				return pathReader(rectangles, squareNumber, "/levels/lvl1path.txt");
			case 2:
				return pathReader(rectangles, squareNumber, "/levels/lvl2path.txt");
			case 3:
				return pathReader(rectangles, squareNumber, "/levels/lvl3path.txt");
			case 4:
				return pathReader(rectangles, squareNumber, "/levels/lvl4path.txt");
			case 5:
				return pathReader(rectangles, squareNumber, "/levels/lvl5path.txt");
			default:
				return null;
		}
		
		
		
	}
	
	ArrayList<int[]> pathReader(Rectangle[][] rectangles, int squareNumber, String path) {
		ArrayList<int[]> coordinates = new ArrayList<>();
		try {
			int squareSize = 720 / squareNumber;
			this.pathLength = 0;
			Point2D initial = pathDemo.localToScene(0, 0);
			String road = new String(getClass().getResourceAsStream(path).readAllBytes());
			double centerX;
            double centerY;
			boolean afterComma = false;
	        int row = 0;
	        int column = 0;
	        for (int i = 0; i < road.length(); i++) {
	        	if (Character.isDigit(road.charAt(i)) && !afterComma) {
	        		row = row * 10 + ((int)road.charAt(i) - '0');
	        	}
	        	else if (Character.isDigit(road.charAt(i)) && afterComma) {
	        		column = column * 10 + ((int)road.charAt(i) - '0');
	        	}
	        	else if (road.charAt(i) == ','){
	        		afterComma = true;
	        	}
	        	else if(road.charAt(i) == '\n') {
	        		this.pathLength++;
	        		rectangles[row][column].setFill(Color.web(randomPathColor()));
	        		centerX = initial.getX() + 6 + (squareSize/2) + (row * (squareSize + 2));
	        		centerY = initial.getY() + 6 + (squareSize/2) + (column * (squareSize + 2));
	        		coordinates.add(new int[]{(int) centerX, (int) centerY});
	        		row = 0;
	        		column = 0;
	            	afterComma = false;
	        	}
	        	
	        	
	        }
	        System.out.println("Path Points:");
	        for (int[] coord : coordinates) {
	            System.out.println("X: " + coord[0] + ", Y: " + coord[1]); //to see the coordinates are correct or not
	        }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return coordinates;
	}
	
}

