package application;
import java.io.FileNotFoundException;

import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GapScenes {
	
	public Scene loseScene(Stage primaryStage) throws InterruptedException {
		StackPane root = new StackPane();
		Scene scene = new Scene(root, 1440, 810);
		VBox pane = new VBox();
        
        root.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/white_bg.png").toString())
    					)
    			);
        
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(150);
        
        Font buttonFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 36);
        Button button = BetterButtons.createButton("Try Again", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
		
        StackPane spLoseLabel = new StackPane();
        Font mainFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 100);
        Text LoseLabelOutline = new Text("YOU LOST");
        LoseLabelOutline.setFont(mainFont);
        LoseLabelOutline.setStroke(Color.RED);
        LoseLabelOutline.setStrokeWidth(6); // Outline Text Settings

        Text gameNameMain = new Text("YOU LOST");
        gameNameMain.setFont(mainFont);
        gameNameMain.setFill(Color.DARKRED); //Main Text Settings
        
        spLoseLabel.getChildren().add(LoseLabelOutline);
        spLoseLabel.getChildren().add(gameNameMain);
        
        pane.getChildren().addAll(spLoseLabel, button);
        root.getChildren().add(pane);
        

        button.setOnAction(e -> {
        	Player.fullReset();
			Scene gameScene = startScene(primaryStage);
			primaryStage.setScene(gameScene);
			primaryStage.setFullScreen(true);
			primaryStage.setFullScreenExitHint("");
			
        });
        
        return scene;
	}
	
    public Scene startScene(Stage primaryStage) {
    	StackPane root = new StackPane();
        VBox pane = new VBox();
        
        root.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/white_bg.png").toString())
    					)
    			);
        
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(150);
        
        Font buttonFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 36);
        Button button = BetterButtons.createButton("Play", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
        
        StackPane spGameName = new StackPane();
        Font mainFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 100);
        Text gameNameOutline = new Text("TOWER DEFENSE GAME");
        gameNameOutline.setFont(mainFont);
        gameNameOutline.setStroke(Color.web("#D4AF37"));
        gameNameOutline.setStrokeWidth(6); // Outline Text Settings

        Text gameNameMain = new Text("TOWER DEFENSE GAME");
        gameNameMain.setFont(mainFont);
        gameNameMain.setFill(Color.web("#FFD700")); //Main Text Settings
        
        spGameName.getChildren().add(gameNameOutline);
        spGameName.getChildren().add(gameNameMain);

        pane.getChildren().addAll(spGameName, button);
        root.getChildren().add(pane);
        Scene menuScene = new Scene(root, 1440, 810);

        button.setOnAction(e -> {
        	try {
        		Player.fullReset();
                GameMaps gameMaps = new GameMaps(1);
                Game.setActiveGameMaps(gameMaps);
                Scene gameScene = gameMaps.GameScene();
                primaryStage.setScene(gameScene);
                primaryStage.setFullScreen(true);
                primaryStage.setFullScreenExitHint("");
                
                Timeline timeline = gameMaps.getMainAnimation();
                Platform.runLater(() -> timeline.play());
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            } catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
        });
        
        return menuScene;
    }
    
    public Scene winScene(Stage primaryStage , int previousLevel) {
    	StackPane root = new StackPane();
        VBox pane = new VBox();
        
        root.getChildren().add(
    			new ImageView(
    					new Image(getClass().getResource("/images/white_bg.png").toString())
    					)
    			);
        
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(150);
        
        Font buttonFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 36);
        Button button;
        if (previousLevel == 5) {
        	button = BetterButtons.createButton("Go Back to Level 1", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
		}
		else {
			button = BetterButtons.createButton("Next Level", buttonFont, new ImageView(new Image(getClass().getResource("/images/start.png").toString())));
		}
        
        
        StackPane spWinLabel = new StackPane();
        Font mainFont = Font.loadFont(getClass().getResourceAsStream("/fonts/shortBabyFont.ttf"), 100);
        Text winLabelOutline = new Text("YOU WON");
        winLabelOutline.setFont(mainFont);
        winLabelOutline.setStroke(Color.web("#D4AF37"));
        winLabelOutline.setStrokeWidth(6); // Outline Text Settings

        Text gameNameMain = new Text("YOU WON");
        gameNameMain.setFont(mainFont);
        gameNameMain.setFill(Color.web("#FFD700")); //Main Text Settings
        
        spWinLabel.getChildren().add(winLabelOutline);
        spWinLabel.getChildren().add(gameNameMain);

        pane.getChildren().addAll(spWinLabel, button);
        root.getChildren().add(pane);
        Scene scene = new Scene(root, 1440, 810);

        button.setOnAction(e -> {
        	try {
        		Player.fullReset();
        		GameMaps gameMaps;
        		if (previousLevel == 5) {
        			gameMaps = new GameMaps(1);
        		}
        		else {
        			gameMaps = new GameMaps(previousLevel + 1);
        		}
                Game.setActiveGameMaps(gameMaps);
                Scene gameScene = gameMaps.GameScene();
                primaryStage.setScene(gameScene);
                primaryStage.setFullScreen(true);
                primaryStage.setFullScreenExitHint("");
                
                Timeline timeline = gameMaps.getMainAnimation();
                Platform.runLater(() -> timeline.play());
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            } catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
        });
        
        return scene;
    }
    
    
}
