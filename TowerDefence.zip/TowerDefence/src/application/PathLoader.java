package application;

import java.io.IOException;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class PathLoader {

	private StackPane[][] stackPanes;
	private Rectangle[][] rectangles;
	
    public void planeCreator(int level, int squareNumber, Timeline sequentialAnimation, GridPane plane) {
    	
    	int squareSize = 720/squareNumber;
    	
    	plane.setMinSize(720 + 10 + (squareNumber * 2), 720 + 10 + (squareNumber * 2));
    	this.rectangles = new Rectangle[squareNumber][squareNumber];
        this.stackPanes = new StackPane[squareNumber][squareNumber];
        
        for (int i = 0; i < squareNumber; i++) {
        	for (int j = 0; j < squareNumber; j++) {
        		
        		rectangles[i][j] = new Rectangle(0, 0);
        		rectangles[i][j].setFill(Color.web(randomGreen()));
        		stackPanes[i][j] = new StackPane();
        		stackPanes[i][j].setPrefSize(squareSize, squareSize);
        		plane.add(stackPanes[i][j], i, j);
        		stackPanes[i][j].getChildren().add(rectangles[i][j]);
        	}
        }
        
        pathLoader(rectangles, level);
        
        for (int i = 0; i < squareNumber; i++) {
            for (int j = 0; j < squareNumber; j++) {
            	
                final int row = i;
                final int col = j;
                
                sequentialAnimation.getKeyFrames().add(
                    new KeyFrame( Duration.millis((i + j) * 120),
                    event -> {
                        animateSquare(this.rectangles[row][col], squareSize);
                    }
                ) );
            }
        }
        
    }
    
    String randomPathColor() {
    	
    	String[] paths = new String[3];
    	paths[0] = "C2A580";
    	paths[1] = "#B99A6E";
    	paths[2] = "#AD8B65";
    	return paths[(int)(Math.random() * 3)];
    }
    
    String randomGreen() {
    	
    	String[] greens = new String[5];
		greens[0] = "#117A11";
		greens[1] = "#0B6A0B";
		greens[2] = "#1A8A1A";
		greens[3] = "#2C9C2C";
		greens[4] = "#106E10";
		return greens[(int)(Math.random() * 5)];
    }
    
    void animateSquare(Rectangle rectangle, int squareSize) {
    	
        Timeline timeline = new Timeline();
        int time = 300;
        
        for (int k = 0; k <= time; k++) {
            
            timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(k),
                    new KeyValue(rectangle.widthProperty(), k * squareSize / time),
                    new KeyValue(rectangle.heightProperty(), k * squareSize / time),
                    new KeyValue(rectangle.arcWidthProperty(), k * squareSize / (time * 4)),
                    new KeyValue(rectangle.arcHeightProperty(), k * squareSize / (time * 4))
                )
            );
        }
        
        timeline.setCycleCount(1);
        timeline.play();
    }

	void pathLoader(Rectangle[][] rectangles,int level) {
		
		switch (level) {
		
			case 1:
				pathReader(rectangles, "/Levels/level1path.txt");
				break;
				
			case 2:
				pathReader(rectangles, "/Levels/level2path.txt");
				break;
				
			case 3:
				pathReader(rectangles, "/Levels/level3path.txt");
				break;
				
			case 4:
				pathReader(rectangles, "/Levels/level4path.txt");
				break;
				
			case 5:
				pathReader(rectangles, "/Levels/level5path.txt");
				break;
		}
	}
	
	void pathReader(Rectangle[][] rectangles, String path) {
		
		try {
			String road = new String(getClass().getResourceAsStream(path).readAllBytes());
			boolean afterComma = false;
	        int row = 0;
	        int column = 0;
	        
	        for (int i = 0; i < road.length(); i++) {
	        	
	        	if (Character.isDigit(road.charAt(i)) && !afterComma) {
	        		row = row * 10 + ((int)road.charAt(i) - '0');
	        	}
	        	
	        	else if (Character.isDigit(road.charAt(i)) && afterComma) {
	        		column = column * 10 + ((int)road.charAt(i) - '0');
	        	}
	        	
	        	else if (road.charAt(i) == ',') {
	        		afterComma = true;
	        	}
	        	
	        	else if(road.charAt(i) == ' ') {
	        		rectangles[row][column].setFill(Color.web(randomPathColor()));
	        		row = 0;
	        		column = 0;
	            	afterComma = false;
	        	}
	        }
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}