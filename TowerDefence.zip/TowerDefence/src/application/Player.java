package application;



import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Player {

	
	static int startingMoney = 3000;
	static int startingLives = 10;
	private static IntegerProperty money = new SimpleIntegerProperty(startingMoney);
	
	private static IntegerProperty lives = new SimpleIntegerProperty(startingLives);
	
	public static IntegerProperty moneyProperty() {
        return money;
    }
	
	public static IntegerProperty livesProperty() {
        return lives;
    }
	
	static void fullReset() {	//to make the game full reset
		WaveSpawn.spawnQueue = null;
		Game.getActiveGameMaps().getSceneChange().stop(); 
		for (Tower tower: Tower.towerList) {
			tower.setIsPlaced(false);
			Game.getActiveGameMaps().getPathDemo().getChildren().remove(tower);
		}
		Tower.towerList.clear();
		for (Enemy enemy: Enemy.enemyList) {
			Game.getActiveGameMaps().getPathDemo().getChildren().remove(enemy);
		}
		Enemy.enemyList.clear();
		money.set(startingMoney);
		lives.set(startingLives);
		
	}
	
	static void playerLost() throws InterruptedException {
		GapScenes lost = new GapScenes();
		WaveSpawn.stopSpawning();
		for (Enemy enemy: Enemy.enemyList) {
			enemy.stopMovement();
			Game.getActiveGameMaps().getPathDemo().getChildren().remove(enemy);
		}
		Game.primaryStage.setScene(lost.loseScene(Game.primaryStage));
		Game.primaryStage.setFullScreen(true);
        Game.primaryStage.setFullScreenExitHint("");
	}
	
	static void changeMoney(int amount) {	// amount can be + or -.
		 money.set(money.get() + amount);
	}
	
	static int getMoney() {
		return money.get();
	}
	
	
	static void changeLives(Enemy e) throws InterruptedException {
		lives.set(lives.get() - e.getDamage());
		
		if (lives.get() <= 0) {
			
			lives.set(0);
			playerLost();
		}
	}
	
	static int getLives() {
		return lives.get();
	}
	
	
	static void changeStartingMoney(int amount) {
		startingMoney = amount;
	}
	
	static void changeStartingLives(int amount) {
		startingLives = amount;
	}
}