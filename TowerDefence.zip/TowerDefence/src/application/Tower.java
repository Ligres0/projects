package application;	// MİRZA

import java.util.ArrayList;
import javafx.scene.layout.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Animation;
import javafx.util.Duration;

abstract class Tower extends Pane {
	
	static ArrayList<Tower> towerList = new ArrayList<Tower>();
	
	protected Timeline timeline;
	private String towerName;
	private int range;
	private int damage;
	private double attackSpeed;		// Attack per Second
	private int damageType;			// 0 - Physical , 1 - Magical , 2 - True Damage
	private int cost;
	private int level = 1;
	private boolean isPlaced = false;
	private boolean isClicked = true;
	private ArrayList<Enemy> enemiesInRange = new ArrayList<Enemy>();
	private String imagePath;

	public Tower clone() {
        try {
            return (Tower) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
	public double getCenterX() {
	    return this.getLayoutX() + (this.getWidth() / 2);
	}

	public double getCenterY() {
	    return this.getLayoutY() + (this.getHeight() / 2);
	}
	
	Tower(String name, int baseRange, int baseDamage, double baseAttackSpeed, int baseDamageType, int baseCost, String imagePath) {
		
		this.towerName = name;
		this.range = baseRange;
		this.damage = baseDamage;
		this.attackSpeed = baseAttackSpeed;
		this.damageType = baseDamageType;
		this.cost = baseCost;
		this.imagePath = imagePath;
	}
	
	public String getImagePath() {
		return imagePath;
	}
	
	public void stopFindEnemies() {
		
        if (this.timeline != null) {
        	
        	this.timeline.stop();
        	this.timeline = null;
        }
    }
	
	void shoot(Enemy e) {
		
	}
	
	public void updateEnemiesInRange(ArrayList<Enemy> Enemies) {
		
	    this.getEnemiesInRange().clear();
	    
	    for (Enemy enemy : Enemies) {
	    	
	        if (enemy != null && enemy.getHp() > 0) {
	        	
	            double distance = this.findDistance(enemy);
	            
	            if (distance <= this.getBaseRange()) {
	                this.getEnemiesInRange().add(enemy);
	            }
	        }
	    }
	}
	
	public double findDistance(Enemy enemy) {
		
		return Math.sqrt(Math.pow(this.getX() - enemy.getTranslateX(), 2) + Math.pow(this.getY() - enemy.getTranslateY(), 2));
	}
	
	public double getX() {
		return this.getLayoutX() + this.getWidth() / 2;
	}
	
	public double getY() {
		return this.getLayoutY() + this.getHeight() / 2;
	}
	
	
	public String getTowerName() {
		return towerName;
	}

	public void setTowerName(String towerName) {
		this.towerName = towerName;
	}
	
	public int getBaseRange() {
		return range;
	}
	
	public void setBaseRange(int baseRange) {
		this.range = baseRange;
	}
	
	public int getBaseDamage() {
		return damage;
	}
	
	public void setBaseDamage(int baseDamage) {
		this.damage = baseDamage;
	}
	
	public int getBaseCost() {
		return cost;
	}
	
	public void setBaseCost(int baseCost) {
		this.cost = baseCost;
	}
	
	public double getBaseAttackSpeed() {
		return attackSpeed;
	}
	
	public void setBaseAttackSpeed(double baseAttackSpeed) {
		this.attackSpeed = baseAttackSpeed;
	}

	public int getDamageType() {
		return damageType;
	}

	public void setDamageType(int damageType) {
		this.damageType = damageType;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	
	public boolean getIsPlaced() {
		return isPlaced;
	}

	public void setIsPlaced(boolean isPlaced) {
		this.isPlaced = isPlaced;
	}

	public boolean getIsClicked() {
		return isClicked;
	}

	public void setIsClicked(boolean isClicked) {
		this.isClicked = isClicked;
	}

	public ArrayList<Enemy> getEnemiesInRange() {
		return enemiesInRange;
	}

	public void setEnemiesInRange(ArrayList<Enemy> enemiesInRange) {
		this.enemiesInRange = enemiesInRange;
	}
}


class WatchTower extends Tower {
	
	static int baseRange = 450;
	static int baseDamage = 100;
	static double baseAttackSpeed = 1.5;
	static int baseDamageType = 0;
	static int baseCost = 200;
	static int[] upgradeCost = {200, 300, 500};
	static String[] upgradeDefinition = {
			"Increase the attack speed.",
			"Increase the range.",
			"Increase the damage."
	};
	
	
	WatchTower() {
		
		super("Watch Tower", baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost, "/images/tower1.png");
		towerList.add(this);
		this.findEnemies();
	}
	
	int towerDmg() {
		
		return this.getBaseDamage();
	}
	
	public void findEnemies() {
			
        if (timeline == null) {
        	
            timeline = new Timeline(
            		
                new KeyFrame(Duration.millis(1000 / this.getBaseAttackSpeed()), event -> {
                    
                	if (this.getIsPlaced()) {
                		
			    	this.updateEnemiesInRange(Enemy.enemyList);
					TowerEffect.effects.add(new Shot(this, this.findClosest()));
                	}
                })
            );
            
            timeline.setCycleCount(Animation.INDEFINITE);
            timeline.play();
        }
	}
	
	public Enemy findClosest() {
		
		if (!this.getEnemiesInRange().isEmpty() && this.getEnemiesInRange() != null) {
			
			if (this.getEnemiesInRange().get(0) != null) {
				
				Enemy closest = this.getEnemiesInRange().get(0);
				
				for (Enemy enemy : this.getEnemiesInRange()) {
					
					if (enemy != null) {
					
						double disC = this.findDistance(closest);
						double disE = this.findDistance(enemy);
						
						if (disE < disC) {
							closest = enemy;
						}
					}
				}
				
				return closest;
			}
			
			else {
				return null;
			}
		
		}
		
		else {
			return null;
		}
	}
	
	void shoot(Enemy target) {
		
	    if (target != null && target.getHp() > 0) { // Null and hp check
	        target.getHurt(this.towerDmg(), this.getDamageType());
	    }
	}
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
				case 1:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseAttackSpeed(2.5);
					break;
					
				case 2:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseRange(150);
					break;
					
				case 3:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseDamage(125);
					break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}
	
	public int getUpgradeCost() {
		return upgradeCost[this.getLevel() - 1];
	}
	
	public String getUpgradeDefinition() {
		return upgradeDefinition[this.getLevel() - 1];
	}
}

class TripleTower extends Tower {
	
	static int baseRange = 450;
	static int baseDamage = 100;
	static double baseAttackSpeed = 1.2;
	static int baseDamageType = 0;
	static int baseCost = 500;
	static int[] upgradeCost = {500, 700, 900};
	static String[] upgradeDefinition = {
			"Increase the attack speed.",
			"Increase the range.",
			"Increase the damage."
	};
	
	
	TripleTower() {
		
		super("Triple Tower", baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost, "/images/tower2.png");
		towerList.add(this);
		this.findEnemies();
	}
	
	int towerDmg() {
		
		return this.getBaseDamage();
	}
	
	public void findEnemies() {
	
        if (timeline == null) {
        	
            timeline = new Timeline(
            		
                new KeyFrame(Duration.millis(1000 / this.getBaseAttackSpeed()), event -> {
                    
                	if (this.getIsPlaced()) {
                	
				    	this.updateEnemiesInRange(Enemy.enemyList);
						ArrayList<Enemy> temp = this.findClosest();
	
						for (Enemy enemy : temp) {
							
							if (enemy != null)
								TowerEffect.effects.add(new Shot(this, enemy));
						}
                	}
                })
            );
            
            timeline.setCycleCount(Animation.INDEFINITE);
            timeline.play();
        }
	}
	
	ArrayList<Enemy> findClosest() {
		
		if (!this.getEnemiesInRange().isEmpty() && this.getEnemiesInRange() != null) {
		
			ArrayList<Enemy> temp = new ArrayList<Enemy>(this.getEnemiesInRange());
			ArrayList<Enemy> closests = new ArrayList<Enemy>();
			
			for (int i = 0 ; i < 3 && temp.size() > 0 ; i++) {
				
				Enemy closest = temp.get(0);
				
				if (closest == null)
					continue;
				
				else {
					for (Enemy enemy : temp) {
						
						if (enemy != null) {
						
							double disC = this.findDistance(closest);
							double disE = this.findDistance(enemy);
							
							if (disE < disC) {
								closest = enemy;
					        }
						}
					}
					
					if (closest != null) {
					
						closests.add(closest);
						temp.remove(closest);
					}
					
					if (temp.size() == 0)
						break;
				}
			}
			
			return closests;
		}
		
		else {
			return null;
		}
	}
	
	void shoot(Enemy target) {
		
		if (target != null)
			target.getHurt(this.towerDmg(), this.getDamageType());
	}
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
				case 1:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseAttackSpeed(2.0);
					break;
					
				case 2:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseRange(150);
					break;
					
				case 3:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseDamage(125);
					break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}
	
	public int getUpgradeCost() {
		return upgradeCost[this.getLevel() - 1];
	}
	
	public String getUpgradeDefinition() {
		return upgradeDefinition[this.getLevel() - 1];
	}
}

class InfernoTower extends Tower {
	
	static int baseRange = 450;
	static int baseDamage = 6;
	static double baseAttackSpeed = 10.0;
	static int baseDamageType = 1;
	static int baseCost = 400;
	static int[] upgradeCost = {400, 550, 700};
	static String[] upgradeDefinition = {
			"Increase the damage.",
			"Increase the range.",
			"Makes the tower ignore any armor."
	};
	
	ArrayList<Laser> lines = new ArrayList<Laser>();
	
	
	InfernoTower() {
		
		super("Inferno Tower", baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost, "/images/tower3.png");
		towerList.add(this);
		this.findEnemies();
	}
	
	int towerDmg() {
		
		return this.getBaseDamage();
	}

	public void findEnemies() {
			
        if (timeline == null) {
        	
            timeline = new Timeline(
            		
                new KeyFrame(Duration.millis(1000 / this.getBaseAttackSpeed()), event -> {
                	
                	if (this.getIsPlaced()) {
                		
	                	// The whole purpose of this unoptimized block is to create new lasers when new enemies get in range but also keep the existing enemies and their Lasers.
                		ArrayList<Enemy> temp1 = new ArrayList<Enemy>(this.getEnemiesInRange());
						this.updateEnemiesInRange(Enemy.enemyList);
						ArrayList<Enemy> temp2 = new ArrayList<Enemy>(this.getEnemiesInRange());
						temp2.removeAll(temp1);		// Finding the new enemies.
						
	                    for (Enemy target : temp2) {	// Creating Laser for new enemies.
	                    	
	                    	if (target != null)
								this.lines.add(new Laser(this, target));
						}
	
						Laser.updateLines(this.lines, this);	// Updating the Laser usage. 
						this.shoot(null);						// Damaging the enemies that still in range of the tower.
                	}
                	
                	else {
                		
                		Laser.updateLines(this.lines, this);
                	}
                })
            );
            
            timeline.setCycleCount(Animation.INDEFINITE);
            timeline.play();
        }
        
	}
	
	void shoot(Enemy uselessPlaceholderSinceThisTowerShootsEveryEnemyAKANullObject) {	// Explained in the argument.
		
		for (Enemy enemy : this.getEnemiesInRange()) { 	// Damaging every enemy one by one quickly.
			
			if (enemy != null)
				enemy.getHurt(this.towerDmg(), this.getDamageType());
		}
	}
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
				case 1:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseDamage(6);
					break;
					
				case 2:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseRange(175);
					break;
					
				case 3:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setDamageType(2);
					break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}
	
	public int getUpgradeCost() {
		return upgradeCost[this.getLevel() - 1];
	}
	
	public String getUpgradeDefinition() {
		return upgradeDefinition[this.getLevel() - 1];
	}
}

class BombTower extends Tower {
	
	static int baseRange = 450;
	static int baseDamage = 200;
	static double baseAttackSpeed = 0.75;
	static int baseDamageType = 0;
	static int baseCost = 450;
	static int[] upgradeCost = {450, 600, 750};
	static int explosionRange = 100;
	static String[] upgradeDefinition = {
			"Increase the attack speed.",
			"Increase the range.",
			"Increase the damage."
	};
	
	
	BombTower() {
		
		super("Bomb Tower", baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost, "/images/tower4.png");
		towerList.add(this);
		this.findEnemies();
	}
	
	int towerDmg() {
		
		return this.getBaseDamage();
	}
	
	public Enemy findClosest() {
		
		if (!this.getEnemiesInRange().isEmpty() && this.getEnemiesInRange() != null) {
		
			if (this.getEnemiesInRange().get(0) != null) {
			
				Enemy closest = this.getEnemiesInRange().get(0);
				
				for (Enemy enemy : this.getEnemiesInRange()) {
					
					if (enemy != null) {
					
						double disC = this.findDistance(closest);
						double disE = this.findDistance(enemy);
						
						if (disE < disC) {
							closest = enemy;
						}
					}
				}
				
				return closest;
			}
			
			else {
				return null;
			}
		}
		
		else {
			return null;
		}
	}

	public void findEnemies() {
		
        if (timeline == null) {
        	
            timeline = new Timeline(
            		
                new KeyFrame(Duration.millis(1000 / this.getBaseAttackSpeed()), event -> {
					
                	if (this.getIsPlaced()) {
                		
					    this.updateEnemiesInRange(Enemy.enemyList);
						TowerEffect.effects.add(new Bomb(this, this.findClosest()));
                	}
                })
            );
            
            timeline.setCycleCount(Animation.INDEFINITE);
            timeline.play();
        }
	}
	
	void shoot(Enemy target) {
		
		if (target != null) {
		
			for (Enemy enemy : this.getEnemiesInRange()) {
				
	            double distanceFromImpact = Math.sqrt( Math.pow(target.getX() - enemy.getX(), 2) + Math.pow(target.getY() - enemy.getY(), 2) );
	            
	            if (distanceFromImpact <= explosionRange) {
	                enemy.getHurt(this.towerDmg(), this.getDamageType());
	            }
	        }
		}
	}
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
				case 1:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseAttackSpeed(0.75);
					break;
					
				case 2:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseRange(225);
					break;
					
				case 3:
					Player.changeMoney(-1 * getUpgradeCost());
					this.setBaseDamage(300);
					break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}
	
	public int getUpgradeCost() {
		return upgradeCost[this.getLevel() - 1];
	}
	
	public String getUpgradeDefinition() {
		return upgradeDefinition[this.getLevel() - 1];
	}
	
}




/**class Bank extends Tower {
	
	static int baseRange = 0;
	static int baseDamage = 0;
	static double baseAttackSpeed = 1.0;
	static int baseDamageType = 2;
	static int baseCost = 600;
	static int baseIncome = 200;
	static int[] upgradeCost = {300, 350, 400};
	static String[] upgradeDefinition = {
			"Increase the generation.",
			"Increase the generation.",
			"Increase the generation."
	};
	
	private int income;
	
	
	Bank() {
		
		super("Bank", baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost);
		towerList.add(this);
		this.income = baseIncome;
	}
	
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
			case 1:
				Player.changeMoney(-1 * getUpgradeCost());
				this.setIncome(300);
				break;
				
			case 2:
				Player.changeMoney(-1 * getUpgradeCost());
				this.setIncome(400);
				break;
				
			case 3:
				Player.changeMoney(-1 * getUpgradeCost());
				this.setIncome(500);
				break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}
	
	public int getUpgradeCost() {
		return upgradeCost[this.getLevel() - 1];
	}
	
	public int getIncome() {	// Add this value to Player.money every new round.
		return income;
	}
	
	public void setIncome(int income) {
		this.income = income;
	}
}

class GlueTower extends Tower {
	
	static int baseRange = 200;
	static int baseDamage = 0;
	static double baseAttackSpeed = 1;
	static int baseDamageType = 2;
	static int baseCost = 250;
	static int baseSlowRate = 25;		// Yüzde olarak.
	
	private int slowRate;
	
	GlueTower() {
		
		super(baseRange, baseDamage, baseAttackSpeed, baseDamageType, baseCost);
		this.slowRate = baseSlowRate;
	}
	
	int towerDmg() {
		
		return this.getBaseDamage();
	}
	
	void shoot() { //TODO: Create bullet objects and make enemies slowed with no damage.
		
		this.findClosest().getHurt(this.towerDmg(), this.getDamageType());
	}
	
	void upgrade() {
		
		if (this.getLevel() < 4) {
		
			switch (this.getLevel()) {
			
				case 1:
					
					break;
					
				case 2:
					
					break;
					
				case 3:
					
					break;
			}
			
			this.setLevel(this.getLevel() + 1);
		}
	}

	public int getSlowRate() {
		return slowRate;
	}

	public void setSlowRate(int slowRate) {
		this.slowRate = slowRate;
	}
}*/