package application;	// MİRZA

import java.util.ArrayList;
import javafx.animation.Interpolator;
import javafx.animation.PathTransition;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.util.Duration;

abstract class TowerEffect extends Shape {		// Superclass carrying our subclasses.

	Tower tower;
	Enemy target;
	double distance;
	Circle bullet;
	Path path;
	PathTransition transition;
	
	static ArrayList<TowerEffect> effects = new ArrayList<TowerEffect>();	// Storing all tower effects together.
	static int shootSpeed = 3000;	// Travel speed of the particle in "Pixels per Second"
	
	
	TowerEffect(Tower tower, Enemy target) {
		
		this.tower = tower;
		this.target = target;
		this.path = new Path();
		this.distance = tower.findDistance(target);
		this.path.getElements().add(new MoveTo(tower.getX(), tower.getY()));	// Setting up the linear path from tower to enemy.
		this.path.getElements().add(new LineTo(target.getTranslateX() + target.getWidth() / 2 ,target.getTranslateY() + target.getHeight() / 2));
		}
	
	
	void setTransition() {		// Absolute core method that making the particle move to enemy AND make the enemy take damage afterward.
		
		this.transition = new PathTransition();
		this.transition.setPath(this.path);
		this.transition.setNode(this.bullet);
		this.transition.setDuration(Duration.seconds(this.distance / shootSpeed));	// Predefining the duration.
		this.transition.setInterpolator(Interpolator.LINEAR);
		
		Game.getActiveGameMaps().getPathDemo().getChildren().add(this.bullet); // to add bullet to the pane
		
		this.transition.setOnFinished(e -> {
			
			if (this.target.getHp() > 0 && target != null)	// This is here to check in case of target dies to another tower's shot before this shot lands.
				tower.shoot(target);
			
			effects.remove(this);
			Game.getActiveGameMaps().getPathDemo().getChildren().remove(this.bullet); // to remove bullet from the pane
			Game.getActiveGameMaps().getPathDemo().getChildren().remove(path);
			this.transition.setPath(null);
			this.transition.setNode(null);
			});

		this.transition.play();
	}
	
}

class Shot extends TowerEffect {		// For WatchTower and TripleTower
	
	
	Shot(Tower tower, Enemy target) {
		
		super(tower, target);
		this.bullet = new Circle(3);
		bullet.setRadius(TowerReplace.getSquareSize() / 9);
		bullet.setFill(Color.RED);
		this.setTransition();
	}
	
	
}

class Laser extends TowerEffect {		// For InfernoTower
	
	private Line line;		// This will be stored in InfernoTower's instance array.
	
	
	Laser(InfernoTower tower, Enemy target) {
		
		super(tower, target);
		this.line = lineGenerator(tower, target);	// Generating the line.
		effects.add(this);
	}
	

	static void updateLines(ArrayList<Laser> lasers, InfernoTower tower) {	// Checks if created Laser will be in use or not.
		
		for (Laser laser : lasers) {
			
			if (laser.target != null) {
			
				if (laser.target.getHp() <= 0 || laser.tower.findDistance(laser.target) > laser.tower.getBaseRange() || !tower.getIsPlaced()) {		// "Removes" Laser.
					
					(laser.getLine()).setFill(Color.TRANSPARENT);
					(laser.getLine()).setStroke(Color.TRANSPARENT);
					tower.lines.remove(laser);
					effects.remove(laser);
				}
			}
			
			else {
				
				(laser.getLine()).setFill(Color.TRANSPARENT);
				(laser.getLine()).setStroke(Color.TRANSPARENT);
				tower.lines.remove(laser);
				effects.remove(laser);
			}
		}
	}
	
	
	static Line lineGenerator(InfernoTower tower, Enemy target) {	// Easy visual and binding setup.
		
		Line line = new Line(tower.getX(),tower.getY()-(TowerReplace.getSquareSize() - 2) / 3 , target.getX(), target.getY());		// Target values does not matter since we are binding them later.
		line.setFill(Color.AQUA);
		line.setStroke(Color.AQUA);
		line.setStrokeWidth(3);
		line.endXProperty().bind(target.translateXProperty().add(target.getWidth() / 2));
		line.endYProperty().bind(target.translateYProperty().add(target.getHeight() / 2));
		Game.getActiveGameMaps().getPathDemo().getChildren().add(line);
		
		return line;
	}
	
	public Line getLine() {
		return this.line;
	}
	
	public void setLine(Line line) {
		this.line = line;
	}
}

class Bomb extends TowerEffect {		// For BombTower
	
	Bomb(Tower tower, Enemy target) {
		
		super(tower, target);
		this.bullet = new Circle();
		bullet.setRadius(TowerReplace.getSquareSize() / 6);
		bullet.setFill(Color.DARKGRAY);
		//bullet.setStroke(Color.BLACK);
		this.setTransition();
	}
	
}