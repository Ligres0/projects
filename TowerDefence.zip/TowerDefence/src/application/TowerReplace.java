package application;

import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.HBox;

public class TowerReplace {
    
    private boolean canAffordTower(Tower tower) {
        return Player.getMoney() >= tower.getBaseCost();
    }
    
    private StackPane sourceCell = null;
    private static int squareSize;
    
    public static void setSquareSize(int squareSize) {
        TowerReplace.squareSize = squareSize;
    }
    
    public static int getSquareSize() {
    	return squareSize;
    }

    public void enableDrag(Button towerButton) {
        towerButton.setOnDragDetected(event -> {
            try {
                Dragboard db = towerButton.startDragAndDrop(TransferMode.MOVE);
                
                ClipboardContent content = new ClipboardContent();
                content.putString(towerButton.getText());
                db.setContent(content);

                if (towerButton.getGraphic() instanceof HBox) {
                    HBox buttonLayer = (HBox) towerButton.getGraphic();
                    for (Node node : buttonLayer.getChildren()) {
                        if (node instanceof ImageView) {
                            ImageView imageView = (ImageView) node;
                            db.setDragView(imageView.getImage());
                            db.setDragViewOffsetX(imageView.getImage().getWidth() / 2);
                            db.setDragViewOffsetY(imageView.getImage().getHeight() / 2);
                            break;
                        }
                    }
                }
                event.consume();
            } catch (Exception e) {
                System.err.println("Drag başlatma hatası: " + e.getMessage());
            }
        });
    }

    public void enableDrop(StackPane[][] stackPanes) {
        if (stackPanes == null) return;
        
        for (int i = 0; i < stackPanes.length; i++) {
            for (int j = 0; j < stackPanes[i].length; j++) {
                StackPane cell = stackPanes[i][j];
                if (cell == null) continue;
                
                setupDragHandlers(cell);
            }
        }
    }
    
    private Tower cloneTower(Tower original) {
        if (original instanceof WatchTower) {
            WatchTower wt = new WatchTower();
            wt.setLevel(original.getLevel());
            wt.setBaseDamage(original.getBaseDamage());
            wt.setBaseRange(original.getBaseRange());
            wt.setBaseAttackSpeed(original.getBaseAttackSpeed());
            wt.setDamageType(original.getDamageType());
            wt.setIsPlaced(original.getIsPlaced());
            
            return wt;
        }
        else if (original instanceof InfernoTower) {
        	InfernoTower it = new InfernoTower();
        	it.setLevel(original.getLevel());        	
            it.setBaseDamage(original.getBaseDamage());
            it.setBaseRange(original.getBaseRange());
            it.setBaseAttackSpeed(original.getBaseAttackSpeed());
            it.setDamageType(original.getDamageType());
            it.setIsPlaced(original.getIsPlaced());
        	return it;
        }
        else if (original instanceof TripleTower) {
        	TripleTower tt = new TripleTower();
        	tt.setLevel(original.getLevel());        	
            tt.setBaseDamage(original.getBaseDamage());
            tt.setBaseRange(original.getBaseRange());
            tt.setBaseAttackSpeed(original.getBaseAttackSpeed());
            tt.setDamageType(original.getDamageType());
            tt.setIsPlaced(original.getIsPlaced());
        	return tt;
        }
        else if (original instanceof BombTower) {
        	BombTower bt = new BombTower();
        	bt.setLevel(original.getLevel());        	
            bt.setBaseDamage(original.getBaseDamage());
            bt.setBaseRange(original.getBaseRange());
            bt.setBaseAttackSpeed(original.getBaseAttackSpeed());
            bt.setDamageType(original.getDamageType());
            bt.setIsPlaced(original.getIsPlaced());
        	return bt;
        }
        return null;
        
    }

    private void setupDragHandlers(StackPane cell) {
        cell.setOnDragDetected(event -> {
            if (hasTower(cell) && !hasPath(cell)) {
                Tower tower = getTowerFromCell(cell);
                if (tower != null ) {
                    tower.setIsPlaced(false);
                    
                    Dragboard db = cell.startDragAndDrop(TransferMode.MOVE);
                    ClipboardContent content = new ClipboardContent();
                    content.putString("MOVE_TOWER");
                    db.setContent(content);
                    
                    sourceCell = cell;
                    
                    ImageView towerImage = getTowerImageView(cell);
                    if (towerImage != null) {
                    	towerImage.setFitWidth(squareSize - 2);
                        towerImage.setFitHeight(squareSize - 2);
                        db.setDragView(towerImage.getImage());
                        db.setDragViewOffsetX(towerImage.getImage().getWidth() / 2);
                        db.setDragViewOffsetY(towerImage.getImage().getHeight() / 2);
                    }
                    
                    event.consume();
                }
            }
        });

        cell.setOnDragOver(event -> {
            if (hasTower(cell)) {
                event.consume();
                return;
            }
            
            if ((event.getGestureSource() instanceof Button && 
                 event.getDragboard().hasString() && 
                 !hasPath(cell) && !hasTower(cell)) ||
                (event.getGestureSource() instanceof StackPane && 
                 event.getDragboard().hasString() && 
                 event.getDragboard().getString().equals("MOVE_TOWER") && 
                 !hasPath(cell) && !hasTower(cell))) {
                
                event.acceptTransferModes(TransferMode.MOVE);
            }
            event.consume();
        });

        cell.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            
            if (hasTower(cell)) {
                event.setDropCompleted(false);
                event.consume();
                return;
            }
            
            if (db.hasString() && !hasPath(cell) && !hasTower(cell)) {
                if (event.getGestureSource() instanceof Button) {
                    // New tower placement
                    Button sourceButton = (Button) event.getGestureSource();
                    Tower originalTower = (Tower) sourceButton.getUserData();
                    
                    if (!canAffordTower(originalTower)) {
                        event.setDropCompleted(false);
                        event.consume();
                        return;
                    }
                    
                    try {
                        // Create new tower instance
                        Tower newTower = cloneTower(originalTower);
                        int[] coords = (int[]) cell.getUserData();
                        int row = coords[0];
                        int col = coords[1];
                        int horizontalDistance = 6 + row * (squareSize + 2) + squareSize / 2;
                        int verticalDistance = 6 + col * (squareSize + 2) + squareSize / 2;
                        newTower.setLayoutX(horizontalDistance);
                        newTower.setLayoutY(verticalDistance);
                        newTower.setIsPlaced(true);
                        
                        // Create image view
                        ImageView towerView = new ImageView(new Image(getClass().getResource(newTower.getImagePath()).toString()));
                        towerView.setFitWidth(squareSize - 2);
                        towerView.setFitHeight(squareSize - 2);
                        
                        // Add to cell
                        cell.getChildren().add(towerView);
                        cell.setUserData(newTower);
                        
                        Player.changeMoney(-newTower.getBaseCost());
                        success = true;
                    } catch (Exception e) {
                        System.err.println("Error creating tower: " + e.getMessage());
                    }
                } 
                else if (event.getGestureSource() instanceof StackPane && db.getString().equals("MOVE_TOWER")) {
                    // Moving existing tower
                    StackPane source = (StackPane) event.getGestureSource();
                    Tower tower = getTowerFromCell(source);
                    
                    if (tower != null && source != cell) {
                        // Update tower position
                        tower.setLayoutX(cell.getLayoutX() + squareSize / 2);
                        tower.setLayoutY(cell.getLayoutY() + squareSize / 2);
                        tower.setIsPlaced(true);
                        
                        // Move visual representation
                        ImageView towerImage = getTowerImageView(source);
                        if (towerImage != null) {
                            ImageView newImageView = new ImageView(towerImage.getImage());
                            newImageView.setFitWidth(squareSize - 2);
                            newImageView.setFitHeight(squareSize - 2);
                            cell.getChildren().add(newImageView);
                            source.getChildren().remove(towerImage);
                        }
                        
                        // Transfer user data
                        cell.setUserData(tower);
                        source.setUserData(null);
                        source.getChildren().removeIf(node -> node instanceof ImageView);
                        success = true;
                    }
                }
            }
            
            event.setDropCompleted(success);
            event.consume();
        });

        cell.setOnDragDone(event -> {
            if (event.getTransferMode() == TransferMode.MOVE && sourceCell != null) {
                if (event.isAccepted() && sourceCell == cell) {
                    Tower tower = getTowerFromCell(cell);
                    if (tower != null) {
                        tower.setIsPlaced(false);
                    }
                    cell.getChildren().removeIf(node -> node instanceof ImageView);
                    cell.setUserData(null);
                }
                sourceCell = null;
            }
            event.consume();
        });
    }
    

    private boolean hasTower(StackPane cell) {
        return getTowerFromCell(cell) != null;
    }

    private boolean hasPath(StackPane cell) {
        return cell.getChildren().stream()
                .anyMatch(node -> {
                    if (!(node instanceof Rectangle)) {
                        return false;
                    }
                    String fillColor = ((Rectangle)node).getFill().toString().toLowerCase();
                    return fillColor.equals("0xc2a580ff") || 
                           fillColor.equals("0xb99a6eff") ||
                           fillColor.equals("0xad8b65ff");
                });
    }
    
    private ImageView getTowerImageView(StackPane cell) {
        for (Node node : cell.getChildren()) {
            if (node instanceof ImageView) {
                return (ImageView) node;
            }
        }
        return null;
    }
    
    public static Tower getTowerFromCell(StackPane cell) {
        if (cell == null) return null;
        Object data = cell.getUserData();
        return (data instanceof Tower) ? (Tower) data : null;
    }

    public void enableTrashBinDrop(StackPane trashBin) {
        trashBin.setOnDragOver(event -> {
            if (event.getGestureSource() instanceof StackPane && 
                event.getDragboard().hasString() && 
                event.getDragboard().getString().equals("MOVE_TOWER")) {
                event.acceptTransferModes(TransferMode.MOVE);
            }
            event.consume();
        });

        trashBin.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            
            if (db.hasString() && db.getString().equals("MOVE_TOWER") && 
                event.getGestureSource() instanceof StackPane) {
                
                StackPane sourceCell = (StackPane) event.getGestureSource();
                Tower tower = getTowerFromCell(sourceCell);
                if (tower != null) {
                    tower.setIsPlaced(false);
                    int refundAmount = (int)(tower.getBaseCost() * 1);
                    Player.changeMoney(refundAmount);
                }
                sourceCell.getChildren().removeIf(node -> node instanceof ImageView);
                sourceCell.setUserData(null);
                success = true;
            }
            
            event.setDropCompleted(success);
            event.consume();
        });

        trashBin.setOnDragEntered(event -> {
            if (event.getGestureSource() instanceof StackPane && 
                event.getDragboard().hasString() && 
                event.getDragboard().getString().equals("MOVE_TOWER")) {
                trashBin.setOpacity(0.7);
            }
        });
        
        trashBin.setOnDragExited(event -> {
            trashBin.setOpacity(1.0);
        });
    }
}