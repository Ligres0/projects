package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Path;
import javafx.util.Duration;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class WaveSpawn {

    static boolean isSpawning;
    static Timeline spawnTimeline;
    static ArrayList<SpawnData> spawnQueue;
    
    static class SpawnData {
        char enemyType;
        
        SpawnData(char enemyType) {
            this.enemyType = enemyType;
        }
    }
    
    public static void stopSpawning() {
    	spawnTimeline.stop();
    }
    private static Enemy createEnemy(char enemyType, Pane gamePane, Path path) {
        Enemy enemy;
        
        switch (enemyType) {
            case 'r':
                enemy = new Rogue();
                break;
            case 'w':
                enemy = new Warrior();
                break;
            case 'g':
                enemy = new Goblin();
                break;
            case 't':
                enemy = new Tank();
                break;
            default:
                return null;
        }
        
        return enemy;
    }

    public static void spawnWave(int level, int wave, double initialTime, 
    		double spawnIntervalSeconds, Pane gamePane, Path path) {
        
        isSpawning = true;
        String filePath = "/level" + level + "/wave" + wave + ".txt";
        spawnQueue = new ArrayList<>();

        try (InputStream is = WaveSpawn.class.getResourceAsStream(filePath);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(" ");
                for (String part : parts) {
                    if (part.length()  < 2) continue;
                    
                    char enemyType = part.charAt(0);
                    try {
                        int amount = Integer.parseInt(part.substring(1));
                        for (int i = 0; i < amount; i++) {
                            spawnQueue.add(new SpawnData(enemyType));
                            System.out.println(enemyType);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid number format in wave file: " + part);
                    }
                }
            }
        } catch (IOException | NullPointerException e) {
            System.err.println("Error loading wave file: " + filePath);
            isSpawning = false;
            return;
        }

        spawnTimeline = new Timeline();
        int[] spawnIndex = {0};
        
        
        
        KeyFrame spawnFrame = new KeyFrame(Duration.seconds(spawnIntervalSeconds), e -> {
            if (spawnIndex[0] < spawnQueue.size()) {
                SpawnData spawnData = spawnQueue.get(spawnIndex[0]);
                Enemy enemy = createEnemy(spawnData.enemyType, gamePane, path);
                
                if (enemy != null) {
                    synchronized (Enemy.enemyList) {
                        Enemy.enemyList.add(enemy);
                    }
                    
                    Platform.runLater(() -> {
                        gamePane.getChildren().add(enemy);
                        gamePane.getChildren().add(enemy.getHBar());
                    });
                    
                    enemy.startMovement();
                }
                
                spawnIndex[0]++;
            }
        });
        
        spawnTimeline.getKeyFrames().add(spawnFrame);
        spawnTimeline.setOnFinished(ev -> isSpawning = false);
        spawnTimeline.setCycleCount(spawnQueue.size());
        
        KeyFrame initialFrame = new KeyFrame(Duration.seconds(initialTime), e -> {
        	spawnTimeline.play();
        });
        
        Timeline waitForInitialTime = new Timeline();
        waitForInitialTime.getKeyFrames().add(initialFrame);
        waitForInitialTime.play();
    }
}